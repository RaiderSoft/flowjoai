exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('404 FlowJoAI route not found'),
    };
    return response;
};
